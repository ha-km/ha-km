<?php
/*
Plugin Name: BebeCreche Location
Plugin URI: http://bebecreche.ma
Version: 1.0
Author: ALGASSE HANANE
Description: This plugin is intended to display the list of nurseries on a map
*/


/****************************
Variables globales
*****************************/

$ahpm_options_ploggmap=get_option('ahpm_settings_ploggmap');

/****************************
Includes
*****************************/

include("includes/functions.php"); // les fonctions
include("includes/assets.php"); // include des js et css
include("includes/poi.php"); // include des POI
include("includes/ploggmap_settings.php"); // page des réglages du plugin


/*******************************
INIT
*********************************/


// Enregister le shortcode : echo do_shortcode('[afficher-map-poi]');
add_action( 'init', 'register_shortcodes');
?>