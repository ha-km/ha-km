<?php

function ahpm_load_ressources() {
	wp_enqueue_style('ahpm-style', plugin_dir_url( __FILE__ ) . 'assets/css/ahpm_style.css');
	wp_enqueue_style('ahpm-style', plugin_dir_url( __FILE__ ) . 'assets/select2/select2.min.css');
	//wp_enqueue_script('ahpm-script-maps', '//maps.googleapis.com/maps/api/js?sensor=false&amp;language=fr');
	wp_enqueue_script('ahpm-script-infobubble', plugin_dir_url( __FILE__ ) . 'assets/js/infobubble.js');
	wp_enqueue_script('ahpm-script-infobubble', plugin_dir_url( __FILE__ ) . 'assets/select2/select2.min.js');
	
}
 
?>