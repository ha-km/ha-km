jQuery(document).ready(function($){

	
	
	

});

var ahpm_addr = "";
function ahpm_getLatLng_poi()
{
	var first=false;
	if(jQuery("#lat_poi").val() == "")
	{
		first=true
	}
	
	/* if(jQuery("#cp_poi").val() != "")
	{
		 ahpm_addr = jQuery("#cp_poi").val();
	}
	else
	{ */
		ahpm_addr = jQuery("#adresse_poi").val();
		
	//}
	
	data= {
		action:"ahpm_get_latlng_poi",
		cp_poi:ahpm_addr
	}
	
	jQuery.post(ajaxurl,data, function(response){
		var map=response.split(',');
		if(map[0] != 'err')
		{
			jQuery("#lat_poi").val(map[0]);
			jQuery("#lng_poi").val(map[1]);
			
			if(first)
			{
				codeAddressFromDB();
			}
			
		}
		else
		{
			alert("Impossible de trouver les coordonnées !");
		}
	})
}


function ahpm_getLatLng_poi_n()
{
alert(1);
	var first=false;
	if(jQuery("#lat_poi").val() == "")
	{
		first=true
	}
			ahpm_addr = jQuery("#adresse_poi").val();
			//ahpm_addr = jQuery("#quartier_creche_poi").val();
			ahpm_ville = jQuery("#ville_creche_poi").val();
	
	if(ahpm_ville == "") {
		alert("<?php _e("Merci de Choisir une ville","ajouterCreche-Step1"); ?>");
		return false;
	}



	data= {
		action:"ahpm_get_latlng_poi_map",
		ahpm_addr:ahpm_addr,
		ahpm_ville:ahpm_ville
	}
	
	jQuery.post(ajaxurl,data, function(response){
		
		var map=response.split(',');
		
		alert(map);
		if(map[0] != 'err')
		{
			jQuery("#lat_poi").val(map[0]);
			jQuery("#lng_poi").val(map[1]);
			//ahpm_initialize_from_fields(map[0],map[1]);
			ahpm_initialize();
			codeAddressFromDBMap1(map[0],map[1]);

			
			if(first)
			{
				//codeAddressFromDBMap();
			}
			
		}
		else
		{
			alert("<?php _e("Impossible de trouver les coordonnées !","ajouterCreche-Step1"); ?>");
		}
	})
}
