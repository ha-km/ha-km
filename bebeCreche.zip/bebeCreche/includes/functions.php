<?php

//==========================================================================
// Methode générale pour la création d'un type d'article
//==========================================================================
function ahpm_add_custom_post_type($name, $args = array()) {
   
	$post_type_name = strtolower(str_replace(' ','_',stripAccents($name)));
	$args = array_merge(array('public' => true,
				  'query_var' => true,
				  'label' => ucwords($name),
				  'labels' => array(
					  'add_new_item' => 'Ajouter une '. ucwords($name), 
					  'edit_item' => 'Modifier une '. ucwords($name), 
					  'view_item' => 'Afficher '.ucwords($name),
					  'rewrite' => false,
					  '_builtin' =>  false),
				  'supports' => array('title', 'editor', 'thumbnail','comments')),
				  $args);
	
	register_post_type($post_type_name, $args);
    
}
function stripAccents2($string){
    return strtr($string, array('à'=>'a','á'=>'a','â'=>'a','ã'=>'a','ä'=>'a','ç'=>'c','è'=>'e','é'=>'e','ê'=>'e','ë'=>'e','ì'=>'i','í'=>'i','î'=>'i','ï'=>'i','ñ'=>'n','ò'=>'o','ó'=>'o','ô'=>'o','õ'=>'o','ö'=>'o','ù'=>'u','ú'=>'u','û'=>'u','ü'=>'u','ý'=>'y','ÿ'=>'y','À'=>'A','Á'=>'A','Â'=>'A','Ã'=>'A','Ä'=>'A','Ç'=>'C','È'=>'E','É'=>'E','Ê'=>'E','Ë'=>'E','Ì'=>'I','Í'=>'I','Î'=>'I','Ï'=>'I','Ñ'=>'N','Ò'=>'O','Ó'=>'O','Ô'=>'O','Õ'=>'O','Ö'=>'O','Ù'=>'U','Ú'=>'U','Û'=>'U','Ü'=>'U','Ý'=>'Y'));
}

//==========================================================================
// Création des Crèches
//==========================================================================

function ahpm_ajouter_poi()
{
	ahpm_add_custom_post_type(
		'creches',
		array(
			'labels' => array(
			'name' => 'Crèches',
			'menu_name' => 'Crèches',
			'singular_name' => 'Crèches',
			'add_new_item' => 'Ajouter une crèche',
			'new_item_name'     => __( 'Ajouter une crèche' ),
			'edit_item' => 'Modifier une crèche',
			'view_item' => 'Afficher une crèche'),
			'menu_icon' => 'dashicons-location-alt', 
			'show_in_menu'        => TRUE,		
			'menu_position' => 21,
			'public' => true,  // it's not public, it shouldn't have it's own permalink, and so on
			'publicly_queriable' => true,  // you should be able to query it
			'show_ui' => true,  // you should be able to edit it in wp-admin
			'exclude_from_search' => true,  // you should exclude it from search results
			'show_in_nav_menus' => false,  // you shouldn't be able to add it to menus
			'has_archive' => false,  // it shouldn't have archive page
			'rewrite' => true,  // it shouldn't have rewrite rules
			'supports'=> array(
			'title','author','comments','page-attributes',
			'thumbnail',
			)
		)
	);

}
add_post_type_support( 'creches', 'comments' );


function ahpm_poi_metabox() {
    add_meta_box( 'poi_metabox',
        'Information de la crèche',
        'ahpm_display_poi_meta_box',
        'creches', 'normal', 'high'
    );
}


/**
 * Display a custom taxonomy dropdown in admin
 * @author Mike Hemberger
 * @link http://thestizmedia.com/custom-post-type-filter-admin-custom-taxonomy/
 */
add_action('restrict_manage_posts', 'tsm_filter_post_type_by_taxonomy');
function tsm_filter_post_type_by_taxonomy() {
	global $typenow;
	$post_type = 'creches'; // change to your post type
	$taxonomy  = 'creche-category'; // change to your taxonomy
	if ($typenow == $post_type) {
		$selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
		$info_taxonomy = get_taxonomy($taxonomy);
		wp_dropdown_categories(array(
			'show_option_all' => __("Show All {$info_taxonomy->label}"),
			'taxonomy'        => $taxonomy,
			'name'            => $taxonomy,
			'orderby'         => 'name',
			'selected'        => $selected,
			'show_count'      => true,
			'hide_empty'      => true,
		));
	};
}
/**
 * Filter posts by taxonomy in admin
 * @author  Mike Hemberger
 * @link http://thestizmedia.com/custom-post-type-filter-admin-custom-taxonomy/
 */
add_filter('parse_query', 'tsm_convert_id_to_term_in_query');
function tsm_convert_id_to_term_in_query($query) {
	global $pagenow;
	$post_type = 'creches'; // change to your post type
	$taxonomy  = 'creche-category'; // change to your taxonomy
	$q_vars    = &$query->query_vars;
	if ( $pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
		$term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
		$q_vars[$taxonomy] = $term->slug;
	}
}

/*** display custom columns **/
add_filter('manage_edit-article_columns', 'my_columns');
function my_columns($columns) {
    $columns['creche-category'] = 'Status';
	return $columns;
}

add_action( 'manage_article_posts_custom_column', 'my_manage_article_columns', 10, 2 );

function my_manage_article_columns( $column, $post_id ) {
global $post;

switch( $column ) {

    /* If displaying the 'article_category' column. */
    case 'creche-category' :

        /* Get the genres for the post. */
        $terms = get_the_terms( $post_id, 'creche-category' );

        /* If terms were found. */
        if ( !empty( $terms ) ) {

            $out = array();

            /* Loop through each term, linking to the 'edit posts' page for the specific term. */
            foreach ( $terms as $term ) {
                $out[] = sprintf( '<a href="%s">%s</a>',
                    esc_url( add_query_arg( array( 'post_type' => 'creches', 'creche-category' => $term->slug ), 'edit.php' ) ),
                    esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'creche-category', 'display' ) )
                );
            }

            /* Join the terms, separating them with a comma. */
            echo join( ', ', $out );
        }

        /* If no terms were found, output a default message. */
        else {
            _e( 'No defined' );
        }

        break;

    /* Just break out of the switch statement for everything else. */
    default :
        break;
}

}
// Enregistrer les informations du POI
function ahpm_enregistrer_infos_poi( $poi_id, $poi ) {
    // s'assurer que le custom post est bien celui de POI
    if ( $poi->post_type == 'creches' ) 
	{
        // Store data in post meta table if present in post data
        if ( isset( $_POST['nom_poi'] ) && $_POST['nom_poi'] != '' ) {
            update_post_meta( $poi_id, 'nom_poi', $_POST['nom_poi'] );
        }
        if ( isset( $_POST['adresse_poi'] ) && $_POST['adresse_poi'] != '' ) {
            update_post_meta( $poi_id, 'adresse_poi', $_POST['adresse_poi'] );
        }
		if ( isset( $_POST['cp_poi'] ) && $_POST['cp_poi'] != '' ) {
            update_post_meta( $poi_id, 'cp_poi', $_POST['cp_poi'] );
        }
		if ( isset( $_POST['lat_poi'] ) && $_POST['lat_poi'] != '' ) {
            update_post_meta( $poi_id, 'lat_poi', $_POST['lat_poi'] );
        }
		if ( isset( $_POST['lng_poi'] ) && $_POST['lng_poi'] != '' ) {
            update_post_meta( $poi_id, 'lng_poi', $_POST['lng_poi'] );
        }
		if ( isset( $_POST['cat_poi'] ) && $_POST['cat_poi'] != '' ) {
            update_post_meta( $poi_id, 'cat_poi', $_POST['cat_poi'] );
        }
		
		if ( isset( $_POST['reg_poi'] ) && $_POST['reg_poi'] != '' ) {
            update_post_meta( $poi_id, 'reg_poi', $_POST['reg_poi'] );
        }
		
		
$types_accueil_poi = "";
            $select_val_types_accueil_poi = $_POST['types_accueil_poi'];
            
            $count_select_val_types_accueil_poi= $_POST['types_accueil_poi'];
            if($count_select_val_types_accueil_poi > 1) {
                $c=1;
                foreach ( $select_val_types_accueil_poi as $key => $value ) {
                    $types_accueil_poi .= $value ;
                    if( $c <  $count_select_val_types_accueil_poi) $types_accueil_poi .= ',';
                    $c++;
                }
            }
            
      
         update_post_meta( $poi_id, 'types_accueil_poi', $types_accueil_poi );
        
		
		if ( isset( $_POST['capacite_poi'] ) && $_POST['capacite_poi'] != '' ) {
            update_post_meta( $poi_id, 'capacite_poi', $_POST['capacite_poi'] );
        }
		$langue_parlees_poi = "";
		if ( isset( $_POST['langue_parlees_poi'] ) && $_POST['langue_parlees_poi'] != '' ) {
			$fisrtb = true;
			foreach ( $_POST['langue_parlees_poi'] as $key => $value ) {
				if ($fisrtb) {
					$langue_parlees_poi .= $value ;
					$fisrtb = false;
				}else{
					$langue_parlees_poi .= ','. $value ;
				}
			}
          	update_post_meta( $poi_id, 'langue_parlees_poi', $langue_parlees_poi );
        }
		 
		if ( isset( $_POST['equipe_nombre_poi'] ) && $_POST['equipe_nombre_poi'] != '' ) {
            update_post_meta( $poi_id, 'equipe_nombre_poi', $_POST['equipe_nombre_poi'] );
        }
		
		if ( isset( $_POST['conges_annuel_poi'] ) && $_POST['conges_annuel_poi'] != '' ) {
            update_post_meta( $poi_id, 'conges_annuel_poi', $_POST['conges_annuel_poi'] );
        }
		
		if ( isset( $_POST['age_accueil_enfants_poi'] ) && $_POST['age_accueil_enfants_poi'] != '' ) {
            update_post_meta( $poi_id, 'age_accueil_enfants_poi', $_POST['age_accueil_enfants_poi'] );
        }
		if ( isset( $_POST['adresse_email_poi'] ) && $_POST['adresse_email_poi'] != '' ) {
            update_post_meta( $poi_id, 'adresse_email_poi', $_POST['adresse_email_poi'] );
        }
		if ( isset( $_POST['telephone_fixe_poi'] ) && $_POST['telephone_fixe_poi'] != '' ) {
            update_post_meta( $poi_id, 'telephone_fixe_poi', $_POST['telephone_fixe_poi'] );
        }
		if ( isset( $_POST['telephone_portable_poi'] ) && $_POST['telephone_portable_poi'] != '' ) {
            update_post_meta( $poi_id, 'telephone_portable_poi', $_POST['telephone_portable_poi'] );
        }
		
		if ( isset( $_POST['prix_max_poi'] ) && $_POST['prix_max_poi'] != '' ) {
            update_post_meta( $poi_id, 'prix_max_poi', $_POST['prix_max_poi'] );
        }
		
		if ( isset( $_POST['prix_min_poi'] ) && $_POST['prix_min_poi'] != '' ) {
            update_post_meta( $poi_id, 'prix_min_poi', $_POST['prix_min_poi'] );
        }
		
		if ( isset( $_POST['ville_creche_poi'] ) && $_POST['ville_creche_poi'] != '' ) {
            update_post_meta( $poi_id, 'ville_creche_poi', $_POST['ville_creche_poi'] );
        }

        if ( isset( $_POST['quartier_creche_poi'] ) && $_POST['quartier_creche_poi'] != '' ) {
            update_post_meta( $poi_id, 'quartier_creche_poi', $_POST['quartier_creche_poi'] );
        }
		if ( isset( $_POST['siteweb_creche'] ) && $_POST['siteweb_creche'] != '' ) {
            update_post_meta( $poi_id, 'siteweb_creche', $_POST['siteweb_creche'] );
        }
		if ( isset( $_POST['facebook_creche'] ) && $_POST['facebook_creche'] != '' ) {
            update_post_meta( $poi_id, 'facebook_creche', $_POST['facebook_creche'] );
        }
		
		
		
		if(isset($_POST['is_main_poi'])){
	    	update_post_meta($poi_id, 'is_main_poi', $_POST['is_main_poi']); 
    	}
		else update_post_meta($poi_id, 'is_main_poi', false); 

		if(isset($_POST['contacter_click_number'])){
	    	update_post_meta($poi_id, 'contacter_click_number', $_POST['contacter_click_number']); 
    	}

    	if(isset($_POST['appler_click_number'])){
	    	update_post_meta($poi_id, 'appler_click_number', $_POST['appler_click_number']); 
    	}
    	if(isset($_POST['localiser_click_number'])){
	    	update_post_meta($poi_id, 'localiser_click_number', $_POST['localiser_click_number']); 
    	} 

    	$terms_category = get_the_terms( $poi_id, 'creche-category' );
		
		$on_category_links = "";
		if ( $terms_category && ! is_wp_error( $terms_category ) ) : 

			$category_links = array();

		foreach ( $terms_category as $term_category  ) {
			$category_links[] = $term_category ->name;
		}

		$on_category_links = join( ", ", $category_links );
		endif;
		if (!empty($category_links) and in_array('Active', $category_links) and (!in_array('approved', $category_links))) {

			$tags = array('active','approved');
			$append = false;
			$taxonomy = 'creche-category';
			wp_set_object_terms( $poi_id, $tags, $taxonomy );
			$to = $_POST['adresse_email_poi'];
			$subject = "[BebeCreche.ma] Votre page a bien été aprouvée ";
			/*$u = new WP_User( $user_id );
			$user = get_userdata( $user_id );
			$to =  $user->user_email;
			$recipient_name = xprofile_get_field_data( 'Name',  $user_id );*/
			$recipient_name = $_POST['nom_poi'];
			$page_link = get_permalink($poi_id);
			$content = " Nous vous informons que votre page a bien été approuvée, elle est maintenant accessible à tout le monde, pour consulter votre page veuillez <a href='$page_link' target='_blank'> cliquer-ici</a>.<br/>Nous restons à votre entière disposition pour toute information supplémentaire.";
			send_customized_email_content($to, $subject, $recipient_name, $content);
    	}
    }
}


// fonction pour afficher le metabox pour les POI
function ahpm_display_poi_meta_box( $poi ) {
    wp_enqueue_script('ahpm_js_poi',plugin_dir_url(__FILE__).'assets/js/ahpm_js_poi.js',array('jquery'));
	
    $nom_poi = esc_html( get_post_meta( $poi->ID, 'nom_poi', true ) );
    $adresse_poi = esc_html( get_post_meta( $poi->ID, 'adresse_poi', true ) );
    $cp_poi = esc_html( get_post_meta( $poi->ID, 'cp_poi', true ) );
    $lat_poi = esc_html( get_post_meta( $poi->ID, 'lat_poi', true ) );
    $lng_poi = esc_html( get_post_meta( $poi->ID, 'lng_poi', true ) );
    $is_main_poi = esc_html( get_post_meta( $poi->ID, 'is_main_poi', true ) );
    $reg_poi = esc_html( get_post_meta( $poi->ID, 'reg_poi', true ) );
	$types_accueil_poi = esc_html( get_post_meta( $poi->ID, 'types_accueil_poi', true ) );
	$capacite_poi = esc_html( get_post_meta( $poi->ID, 'capacite_poi', true ) );
	$langue_parlees_poi = get_post_meta( $poi->ID, 'langue_parlees_poi', true );
	$equipe_nombre_poi = esc_html( get_post_meta( $poi->ID, 'equipe_nombre_poi', true ) );
	$conges_annuel_poi = esc_html( get_post_meta( $poi->ID, 'conges_annuel_poi', true ) );
	$age_accueil_enfants_poi = esc_html( get_post_meta( $poi->ID, 'age_accueil_enfants_poi', true ) );
	$adresse_email_poi = esc_html( get_post_meta( $poi->ID, 'adresse_email_poi', true ) );
	$telephone_fixe_poi = esc_html( get_post_meta( $poi->ID, 'telephone_fixe_poi', true ) );
	$telephone_portable_poi = esc_html( get_post_meta( $poi->ID, 'telephone_portable_poi', true ) );
	$prix_max_poi = esc_html( get_post_meta( $poi->ID, 'prix_max_poi', true ) );
	$prix_min_poi = esc_html( get_post_meta( $poi->ID, 'prix_min_poi', true ) );
	$ville_creche_poi = esc_html( get_post_meta( $poi->ID, 'ville_creche_poi', true ) );
	$quartier_creche_poi = esc_html( get_post_meta( $poi->ID, 'quartier_creche_poi', true ) );
	$localiser_click_number = esc_html( get_post_meta( $poi->ID, 'localiser_click_number', true ) );
	$appler_click_number = esc_html( get_post_meta( $poi->ID, 'appler_click_number', true ) );
	$contacter_click_number = esc_html( get_post_meta( $poi->ID, 'contacter_click_number', true ) );
	$siteweb_creche = esc_html( get_post_meta( $poi->ID, 'siteweb_creche', true ) );
	$facebook_creche = esc_html( get_post_meta( $poi->ID, 'facebook_creche', true ) );

	$langue_parlees_poi = explode(",", $langue_parlees_poi);
	$types_accueil_poi = explode(",", $types_accueil_poi);
	
	
	ob_start()
    ?>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyChQ4qX52hXARpq8RHfr8oWrAqxJDSySck" type="text/javascript"></script>
	<link href="<?php echo bloginfo('template_url');?>/libs/select2/select2.min.css" rel="stylesheet" />
	<link rel="stylesheet" id="custom-css" href="<?php echo bloginfo('template_url');?>/libs/searchable/sol.css" type="text/css" media="all">

	<script type="text/javascript" src="<?php echo bloginfo('template_url');?>/libs/searchable/sol.js"></script>

	<script type="text/javascript" src="<?php echo bloginfo('template_url');?>/libs/select2/select2.min.js"></script>
    
	<script type="text/javascript">
		/*
		jQuery('#langue_parlees_poi').searchableOptionList({
		showSelectionBelowList:true,
		allowNullSelection: true
		});*/
		
			</script>
    <table>
       <!-- <tr>
            <td style="width: 100%">Point central ?</td>
            <td><input type="checkbox" <?=($is_main_poi)?"checked":""?> name="is_main_poi" /></td>
        </tr>-->
		<tr>
            <td style="width: 100%">Non de l'établissement</td>
            <td><input type="text" size="80" name="nom_poi" value="<?php echo $nom_poi; ?>" /></td>
        </tr>
       
         <!--
		<tr>
            <td style="width: 150px">Code postal</td>
           
            <td><input type="text" size="80" name="cp_poi" id="cp_poi" value="<?php echo $cp_poi; ?>" /></td>
            
        </tr>
       
		<tr>
			<td style="width: 150px">Région</td>
			<td>
				<select name="reg_poi">
					<option value="0">Choisir une région</option>
					-->
					<?php 
						/*$regions = GetListRegion(); 
						
						foreach ($regions as $value) {
							
							?>
							<option value="<?php echo $value->id; ?>" <?= ($reg_poi == $value->id)? "selected":"" ?>><?php echo $value->region;?></option>

							<?php
						}*/
					?>
<!--
				</select>
			</td>
		</tr>
-->
		<tr> 
			<td style="width: 150px">Ville</td>
			<td>
				<select name="ville_creche_poi">
					<option value="0">Choisir une ville</option>
					<?php 	
						$cities = GetListCities(); 
						
						foreach ($cities as $value) {
							
							?>
							<option value="<?php echo $value->id; ?>" <?= ($ville_creche_poi == $value->id)? "selected":"" ?>><?php echo $value->ville;?>
							</option>

							<?php
						}
					?>
					
				</select>
			</td>
		</tr>

		<tr>
			<td style="width: 150px">Quartier</td>
			<td>
				 <select name="quartier_creche_poi" id="quartier_creche_poi" data-live-search="true">
                  <option value="0"><?php _e("Selectionnez un quartier","homePage"); ?></option>
                  <?php   
                 $quartiers = GetListQuartier(); 

                  foreach ($quartiers as $value) {

                    ?>
                    <option value="<?php echo $value->id; ?>" <?= ($quartier_creche_poi == $value->id)? "selected":"" ?>><?php echo $value->quartier;?></option>

                    <?php
                  }
                  ?>

                </select>
			</td>
		</tr>
		 <tr>
            <td style="width: 150px">Adresse</td>
           
            <td><input type="text" size="80" name="adresse_poi" id="adresse_poi" value="<?php echo $adresse_poi; ?>" /></td>
           
        </tr>
		<tr>
			<td colspan="2"><input type="button" class="button" onClick="ahpm_getLatLng_poi_n()" value="<?php _e('Générer les coordonnées de la MAP','creche'); ?>"/></td>
		</tr>
		<tr>
            <td style="width: 150px">Latitude (Facultatif)</td>
           
            <td><input type="text" size="80" name="lat_poi" id="lat_poi" value="<?php echo $lat_poi; ?>" /></td>
            
        </tr>
		<tr>
            <td style="width: 150px">Longitude (Facultatif)</td>
           
            <td><input type="text" size="80" name="lng_poi" id="lng_poi" value="<?php echo $lng_poi; ?>" /></td>  

					
        </tr>
		
		
    </table>
	<div id="msg-carte">
	<?php _e("	<b>Localiser</b>: déplacer le pointeur sur la carte pour préciser les coordonnées de la crèche","creche"); ?>
	</div>
	<div id="map-canvas" style="height: 300px;"></div>
	<br/><br/>
	<table>
	
	<tr>
            <td style="width: 150px">Téléphone Fixe</td>
           
            <td><input type="text" size="80" name="telephone_fixe_poi" id="telephone_fixe_poi" value="<?php echo $telephone_fixe_poi; ?>" /></td>  	
        </tr>
		
		
		<tr>
            <td style="width: 150px">Téléphone Portable</td>
           
            <td><input type="text" size="80" name="telephone_portable_poi" id="telephone_portable_poi" value="<?php echo $telephone_portable_poi; ?>" /></td>  	
        </tr>
		
		<tr>
            <td style="width: 150px">Adresse Email</td>
           
            <td><input type="text" size="80" name="adresse_email_poi" id="adresse_email_poi" value="<?php echo $adresse_email_poi; ?>" /></td>  	
        </tr>
	<tr>
			<td style="width: 150px">Catégorie - Type d'accueil</td>
			<td>
				<select name="types_accueil_poi[]" id="types_accueil_poi" multiple="multiple">
					<option>Aucune</option>
					<option value="cat1"  <?php  if (is_array($types_accueil_poi) && in_array("cat1", $types_accueil_poi)) { echo "selected";}?>>Les crèches collectives</option>
					<option value="cat2" <?php  if (is_array($types_accueil_poi) && in_array("cat2", $types_accueil_poi)) { echo "selected";}?>>La halte-garderie</option>
					<option value="cat3" <?php  if (is_array($types_accueil_poi) && in_array("cat3", $types_accueil_poi)) { echo "selected";}?>>Les jardins d'enfants</option>
					<option value="cat4" <?php  if (is_array($types_accueil_poi) && in_array("cat4", $types_accueil_poi)) { echo "selected";}?>>Le "multi-accueil"</option>
					<option value="cat5" <?php  if (is_array($types_accueil_poi) && in_array("cat5", $types_accueil_poi)) { echo "selected";}?>>Ecole Maternelle</option>
					<option value="cat6" <?php  if (is_array($types_accueil_poi) && in_array("cat6", $types_accueil_poi)) { echo "selected";}?>>Ecole Primaire</option>
					<option value="cat7" <?php  if (is_array($types_accueil_poi) && in_array("cat7", $types_accueil_poi)) { echo "selected";}?>>Club de jeux</option>
				</select>
			</td>
			<br/>
		</tr>
		
		<tr>
            <td style="width: 150px">Capacité d'accueil</td>
           
            <td><input type="text" size="80" name="capacite_poi" id="capacite_poi" value="<?php echo $capacite_poi; ?>" /></td>  	
        </tr>
		
		<tr>
            <td style="width: 150px">Langue(s) parlée(s) </td>
           

            <td>
				<select name="langue_parlees_poi[]"  id="langue_parlees_poi" multiple="multiple" style="width:100%">
				<option value="Arabe" <?php  if (is_array($langue_parlees_poi) && in_array("Arabe", $langue_parlees_poi)) { echo "selected";}?>><?php _e("Arabe","ajouterCreche-Step1"); ?></option>
					<option value="Français" <?php  if (is_array($langue_parlees_poi) && in_array("Français", $langue_parlees_poi)) { echo "selected";}?>><?php _e("Français","ajouterCreche-Step1"); ?></option>
					<option value="Anglais" <?php  if (is_array($langue_parlees_poi) && in_array("Anglais", $langue_parlees_poi)) { echo "selected";}?>><?php _e("Anglais","ajouterCreche-Step1"); ?></option>
					<option value="Espagnole"<?php  if (is_array($langue_parlees_poi) && in_array("Espagnole", $langue_parlees_poi)) {echo "selected";}?>><?php _e("Espagnole","ajouterCreche-Step1"); ?></option>

					<option value="Allemand"<?php  if (is_array($langue_parlees_poi) && in_array("Allemand", $langue_parlees_poi)) {echo "selected";}?>><?php _e("Allemand","ajouterCreche-Step1"); ?></option>
				</select>
			</td>  	
        </tr>
		
		<tr>
            <td style="width: 150px">Equipe (Nombre des personnes)</td>
           
            <td><input type="text" size="80" name="equipe_nombre_poi" id="equipe_nombre_poi" value="<?php echo $equipe_nombre_poi; ?>" /></td>  	
        </tr>
		
		<tr>
            <td style="width: 150px">Congés annuel (Nom du mois)</td>
           
            <td>
			
			<select name="conges_annuel_poi">
					<option value="">Aucun</option>
					<option value="1" <?= ($conges_annuel_poi == "1")? "selected":"" ?>>Janvier</option>
					<option value="2" <?= ($conges_annuel_poi == "2")? "selected":"" ?>>Février</option>
					<option value="3" <?= ($conges_annuel_poi == "3")? "selected":"" ?>>Mars</option>
					<option value="4" <?= ($conges_annuel_poi == "4")? "selected":"" ?>>Avril</option>
					<option value="5" <?= ($conges_annuel_poi == "5")? "selected":"" ?>>Mai</option>
					<option value="6" <?= ($conges_annuel_poi == "6")? "selected":"" ?>>Juin</option>
					<option value="7" <?= ($conges_annuel_poi == "7")? "selected":"" ?>>Juillet</option>
					<option value="8" <?= ($conges_annuel_poi == "8")? "selected":"" ?>>Août</option>
					<option value="9" <?= ($conges_annuel_poi == "9")? "selected":"" ?>>Septembre</option>
					<option value="10" <?= ($conges_annuel_poi == "10")? "selected":"" ?>>Octobre</option>
					<option value="11" <?= ($conges_annuel_poi == "11")? "selected":"" ?>>Novembre</option>
					<option value="12" <?= ($conges_annuel_poi == "12")? "selected":"" ?>>Décembre</option>
					
				</select></td>  	
        </tr><tr>
            <td style="width: 150px">Age d'accueil des enfants exp(3 mois - 5 an(s))</td>
           
            <td><input type="text" size="80" name="age_accueil_enfants_poi" id="age_accueil_enfants_poi" value="<?php echo $age_accueil_enfants_poi; ?>" /></td>  	
        </tr>
		
		<tr>
            <td style="width: 150px">Prix Min</td>
           
            <td><input type="text" size="80" name="prix_min_poi" id="prix_min_poi" value="<?php echo $prix_min_poi; ?>" /> DHs</td>  	
        </tr>
		
		<tr>
            <td style="width: 150px">Prix Max</td>
           
            <td><input type="text" size="80" name="prix_max_poi" id="prix_max_poi" value="<?php echo $prix_max_poi; ?>" /> DHs</td>  	
        </tr>
<tr>
            <td style="width: 150px">Site web</td>
           
            <td><input type="text" size="80" name="siteweb_creche" id="siteweb_creche" value="<?php echo $siteweb_creche; ?>" /> DHs</td>  	
        </tr>

        <tr>
            <td style="width: 150px">Page Facebook</td>
           
            <td><input type="text" size="80" name="facebook_creche" id="facebook_creche" value="<?php echo $facebook_creche; ?>" /> DHs</td>  	
        </tr>

        <tr>
            <td style="width: 150px">localiser Button: click number</td>
           
            <td><input type="text" size="80" name="localiser_click_number" id="localiser_click_number" value="<?php echo $localiser_click_number; ?>" /> DHs</td>  	
        </tr>

        <tr>
            <td style="width: 150px">Appler Button: click number</td>
           
            <td><input type="text" size="80" name="appler_click_number" id="appler_click_number" value="<?php echo $appler_click_number; ?>" /> DHs</td>  	
        </tr>

        <tr>
            <td style="width: 150px">Contacter Button: click number</td>
           
            <td><input type="text" size="80" name="contacter_click_number" id="contacter_click_number" value="<?php echo $contacter_click_number; ?>" /> DHs</td>  	
        </tr>
		
    </table>
	<script type="text/javascript">

	jQuery(document).ready(function(){

		jQuery("#langue_parlees_poi").select2({
			placeholder: "<?php _e("les langues parlées","ajouterCreche-Step1"); ?>"
		});   

		jQuery("#types_accueil_poi").select2({
			placeholder: "<?php _e("la Catégorie","ajouterCreche-Step1"); ?>"
		});   
				
		ahpm_initialize();
		codeAddressFromDB();
    
		
	});
	
	var geocoder;
var map;
var marker;

function ahpm_initialize() 
{
  geocoder = new google.maps.Geocoder();
  var latlng = new google.maps.LatLng(56.130, -106.346);
  var mapOptions = {
    zoom: 5,
    center: latlng,
	zoomControl:true,
	zoomControlOptions: {
		style: google.maps.ZoomControlStyle.SMALL
	},
    mapTypeId: google.maps.MapTypeId.ROADMAP,
    <?= ($ahpm_options_ploggmap['style_map'] != "")? "styles:".$ahpm_options_ploggmap['style_map']:"" ?>
  }
  
  map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
  
  marker = new google.maps.Marker({
          map: map,
		  draggable:true,
		icon:'<?php bloginfo('template_url'); ?>/images/pin.png'
		 // position: latlng
          
      });
}

function codeAddressFromDB() 
{


    if('<?= $lat_poi?>' == '' && '<?= $lng_poi?>' == '')
	{
		if(document.getElementById('lat_poi').value != "" && document.getElementById('lng_poi').value != "" )
		var latLng=new google.maps.LatLng(document.getElementById('lat_poi').value, document.getElementById('lng_poi').value);
		else var latLng=new google.maps.LatLng(33,7);
		
	}
	
	else var latLng=new google.maps.LatLng('<?= $lat_poi?>','<?= $lng_poi?>');
      map.setCenter(latLng);
	  map.setZoom(17);
	  marker.Position=latLng;
      marker = new google.maps.Marker({
          map: map,
		  draggable:true,
          position: latLng,
         // icon:'<?php bloginfo('template_url'); ?>/images/pin.png'
      });
	  
	google.maps.event.addListener(marker, 'dragend', function(event) {
	         

		document.getElementById('lat_poi').value=this.getPosition().lat();
		document.getElementById('lng_poi').value=this.getPosition().lng();
		

	});
	  
	  
		
    
  
}

	
	</script>
    <?php
	
	echo ob_get_clean();
}

function register_shortcodes()
{
	add_shortcode("afficher-map-creche", "ahpm_afficher_map_poi_handler");
	add_shortcode("afficher-liste-creche", "ahpm_afficher_liste_poi_handler");
}
function ahpm_afficher_liste_poi_handler()
{
	query_posts(array('post_type' => 'creches','orderby' => 'date', 'order' => 'DESC'));
	$html = "<ul id='ahpm_liste_poi'>";
	if (have_posts()) :
		while (have_posts()) : the_post();
			
			$id_poi=get_the_ID();
			$nom_poi = esc_html( get_post_meta( $id_poi, 'nom_poi', true ) );
					
			$is_main_poi = esc_html( get_post_meta( $id_poi, 'is_main_poi', true ) );
			if($is_main_poi) continue;
			
			$html .= "<li>$nom_poi</li>";
			
		endwhile;
		$html .="</ul>";
	endif;
	wp_reset_query();
	
	echo $html;
		
}
function ahpm_afficher_map_poi_handler($atts) 
{	
	
  ahpm_load_ressources();
  global $ahpm_options_ploggmap;
  
  $atts = shortcode_atts(
		array(
			'width' => $ahpm_options_ploggmap['width_map'],
			'height' => $ahpm_options_ploggmap['height_map'],
			'principales_seulement' => 'no',
			'centrer_principal' => 'no',
			'filtre' => 'no',
			'cat_id' => 'no',
			'legende' => 'no'
			
		), $atts, 'afficher-map-creche' );
	$locations='[';
	$i=0;
	
	
		query_posts(array('post_type' => 'creches','orderby' => 'date', 'order' => 'DESC'));
	
   if (have_posts()) :
      while (have_posts()) : the_post();
        
		$id_poi=get_the_ID();
		$cat_poi = get_post_meta( $id_poi, 'cat_poi', true ) ;
		if($atts['cat_id'] != 'no')
		{
			if($cat_poi != $atts['cat_id']) continue;
		}
		$nom_poi = esc_html( get_post_meta( $id_poi, 'nom_poi', true ) );
		$adresse_poi = esc_html( get_post_meta( $id_poi, 'adresse_poi', true ) );
		$ville_creche_poi = esc_html( get_post_meta( $poi->ID, 'ville_creche_poi', true ) );
		$cp_poi = esc_html( get_post_meta( $id_poi, 'cp_poi', true ) );
		$lat_poi = get_post_meta( $id_poi, 'lat_poi', true );
		$lng_poi = get_post_meta( $id_poi, 'lng_poi', true ) ;
		
		
		$reg_poi = get_post_meta( $id_poi, 'reg_poi', true ) ;
		$is_main_poi = esc_html( get_post_meta( $id_poi, 'is_main_poi', true ) );
		if($atts['principales_seulement'] == 'yes')
		{
			if($is_main_poi != true) continue;
		}
		$id_img=get_post_thumbnail_id($id_poi);
		if($id_img)
		{
			$url_image = wp_get_attachment_url( $id_img );
		}
		else
		{
			$url_image = "";
		}
		if(!is_numeric($lng_poi) || !is_numeric($lat_poi))
		{
			$map    =   ahpm_get_lat_long($adresse_poi,$ville_creche_poi);
			$arr_map=explode(",",$map);
			//print_r(">>>>".$latlong);
			
			if($i < 1){
				$locations.='["'.addslashes($nom_poi).'","'.$arr_map[0].'","'.$arr_map[1].'","'.$cp_poi.'","'.$adresse_poi.'","'.$ville_creche_poii.'","'.$is_main_poi.'","'.$url_image.'","'.$cat_poi.'","'.$reg_poi.'"]';
			}else{
				$locations.=',["'.addslashes($nom_poi).'","'.$arr_map[0].'","'.$arr_map[1].'","'.$cp_poi.'","'.$adresse_poi.'","'.$ville_creche_poii.'","'.$is_main_poi.'","'.$url_image.'","'.$cat_poi.'","'.$reg_poi.'"]';
			}
			update_post_meta( $id_poi, 'lat_poi', $arr_map[0] );
			update_post_meta( $id_poi, 'lng_poi', $arr_map[1] );
		}
		else
		{
			if($i < 1){
				$locations.='["'.addslashes($nom_poi).'","'.$lat_poi.'","'.$lng_poi.'","'.$cp_poi.'","'.$adresse_poi.'","'.$ville_creche_poii.'","'.$is_main_poi.'","'.$url_image.'","'.$cat_poi.'","'.$reg_poi.'"]';
			}else{
				$locations.=',["'.addslashes($nom_poi).'","'.$lat_poi.'","'.$lng_poi.'","'.$cp_poi.'","'.$adresse_poi.'","'.$ville_creche_poii.'","'.$is_main_poi.'","'.$url_image.'","'.$cat_poi.'","'.$reg_poi.'"]';
			}
		}
		$i++;
      endwhile;
	  $locations.=']';
   endif;
   wp_reset_query();
   
   
   ?>
   <div id="ahpm_map_canvas" style="width:<?= ($atts['width'] != "")? $atts['width']:"500px" ?>;height: <?= ($atts['height'] != "")? $atts['height']:"400px" ?>;"></div>
   <style>
		.gmnoprint img {
		max-width: none; 
	}
   </style>
   <?php
   if($atts['cat_id'] == 'no' && $atts['legende'] == 'yes')
	{
   ?>
   <div id="ahpm_map_legend" style="width:180px;bottom:14px;right:0;padding:1em;background:#fff;">
	  <h2 style="font-size:2em;">Légende</h2>
	  <?php
		if($ahpm_options_ploggmap['cat5_pin_map'])
		{
			?>
			<img src="<?= get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat5_pin_map'] ?>"> <b>ANEER - Préscolaire</b><br/>
			<?php
		}
	  ?>
	  
	  
	  <?php
		if($ahpm_options_ploggmap['cat2_pin_map'])
		{
			?>
			<img src="<?= get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat2_pin_map'] ?>"> <b>ENF</b><br/>
			<?php
		}
	  ?>
	   <?php
		if($ahpm_options_ploggmap['cat1_pin_map'])
		{
			?>
			<img src="<?= get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat1_pin_map'] ?>"> <b>École Numérique</b><br/>
			<?php
		}
	  ?>
	  
	  <?php
		if($ahpm_options_ploggmap['cat3_pin_map'])
		{
			?>
			<img src="<?= get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat3_pin_map'] ?>"> <b>Programme Intégré</b><br/>
			<?php
		}
	  ?>
	 
	  
	  <?php
		if($ahpm_options_ploggmap['cat4_pin_map'])
		{
			?>
			<img src="<?= get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat4_pin_map'] ?>"> <b>Formation des jeunes</b><br/>
			<?php
		}
	  ?>

	

	  <?php
		if($ahpm_options_ploggmap['cat6_pin_map'])
		{
			?>
			<img src="<?= get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat6_pin_map'] ?>"> <b>Alphabétisation</b><br/>
			<?php
		}
	  ?>
	  
	  <?php
		if($ahpm_options_ploggmap['cat7_pin_map'])
		{
			?>
			<img src="<?= get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat7_pin_map'] ?>"> <b>Écocitoyenneté</b><br/>
			<?php
		}
	  ?>
	</div>
	<?php
	}
	?>
	<?php
	if($atts['filtre'] == 'yes')
	{
	?>
		<div style="width:25%;height:100%;float:right;color:white;  padding: 20px 40px;text-transform:uppercase;"><h5>localisez un projets</h5>
			
			<div class="ts-donation">	
				<select name="ahpm_programmes" id="ahpm_programmes" class="donate_sel" style="width:100%;width:100%;  font-size: 1.2em;  color: #000;">
					<option value="0">Tous les projets</option>
					 <option value="cat5">ANEER - Préscolaire</option>
					  <option value="cat2">ENF</option>
					 <option value="cat1">École Numérique</option>
					 <option value="cat3">Programme Intégré</option>
					 <option value="cat4">Formation des jeunes</option>
					 <option value="cat6">Alphabétisation</option>
					 <option value="cat7">Écocitoyenneté</option>
					
				</select>
				<select name="ahpm_regions" id="ahpm_regions" class="donate_sel" style="width:100%;  font-size: 1.2em;  color: #000;">
					<option value="0">Toutes les régions</option>
					<?php 

					?>
					<option value="Doukkala-Abda">Doukkala-Abda</option>
					<option value="tanger-tetouan">Tanger - Tetouan</option>
					<option value="Gharb-Chrarda-Beni hssen">Gharb-Chrarda-Beni hssen</option>
					<option value="Marrakech - Tansift - Haouz">Marrakech - Tansift - Haouz</option>
					<option value="Grand Casablanca">Grand Casablanca</option>
					<option value="Rabat-Salé-Zemmour-Zaër">Rabat-Salé-Zemmour-Zaër</option>
										
				</select>
				
				<input type="button" border="0" value="Lancer la recherche" name="ahpm_flitrer" onClick="ahpm_filtrer()" class="button" style="width:100%;font-size: 1.2em;">
				
		</div>
		</div>
	<?php
	}
	?>
	
   <script type="text/javascript">
  
    

<?php
	 if($atts['cat_id'] == 'no' && $atts['legende'] == 'yes')
		{
	 ?>
   var html_ahpm_map_legend = "";
   var style_ahpm_map_legend = "";
   var class_ahpm_map_legend = "";
   
   <?php
		}
   ?>
   jQuery(document).ready(function(){
		ahpm_initialize();
		
		<?php
		if($atts['cat_id'] == 'no' && $atts['legende'] == 'yes')
		{
	 ?>
		html_ahpm_map_legend = jQuery("#ahpm_map_legend").html();
		style_ahpm_map_legend = jQuery("#ahpm_map_legend").attr('style');
		class_ahpm_map_legend = jQuery("#ahpm_map_legend").attr('style');
		
		<?php
		}
		?>
	});
	
	
	function ahpm_filtrer()
	{
		var all_locations=<?=$locations?>;
		
		var prj = jQuery("#ahpm_programmes").val();
		var reg = jQuery("#ahpm_regions").val();
		
		var filtred_loc = new Array();
		if(prj != "0" && reg == "0")
		{
			jQuery.each(all_locations, function( index, value ) {
			  if(value[7] == prj)
			  {
				  filtred_loc.push(value);
			  }
			});
		}
		
		if(reg != "0" && prj == "0")
		{
			jQuery.each(all_locations, function( index, value ) {
			  if(value[8] == reg)
			  {
				  filtred_loc.push(value);
			  }
			});
		}
		
		if(reg != "0" && prj != "0")
		{
			jQuery.each(all_locations, function( index, value ) {
			  if(value[7] == prj && value[8] == reg)
			  {
				  filtred_loc.push(value);
			  }
			});
				
			
		}
		
		if(reg == "0" && prj == "0")
		{
			ahpm_initialize();
		}
		else
		{
			if(!jQuery.isEmptyObject(filtred_loc))
			{
				ahpm_initialize_filtred(filtred_loc);
			}
			else
			{
				alert("Aucun résultat trouvé !");
				ahpm_initialize();
			}
		}
		
		
	}
	
	
	var markers=[];
	var infoBubble;
	
	function ahpm_initialize() {
	
		locations=<?=$locations?>;
		
	  geocoder = new google.maps.Geocoder();
	  var latlng = new google.maps.LatLng(45.400994, -7.882428);
	  var mapOptions = {
		zoom: 12,
		minZoom: 6,
		center: latlng,
		scrollwheel: false,
		disableDefaultUI: true,
		mapTypeControl: false,
		zoomControl: true,
		zoomControlOptions: {
		    style: google.maps.ZoomControlStyle.SMALL
		},
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		
		<?= ($ahpm_options_ploggmap['style_map'] != "")? "styles:".$ahpm_options_ploggmap['style_map']:"" ?>
	  }
	  
	  map = new google.maps.Map(document.getElementById('ahpm_map_canvas'), mapOptions);
	  
	 <?php
	 if($atts['cat_id'] == 'no' && $atts['legende'] == 'yes')
		{
	 ?>
	  if(jQuery("#ahpm_map_legend").attr('id') == "ahpm_map_legend")
	  {
		
		map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(document.getElementById('ahpm_map_legend'));
		  
	  }
	  else  
	  {
		jQuery("#ahpm_map_canvas").after("<div id='ahpm_map_legend' style='"+style_ahpm_map_legend+"' class='"+class_ahpm_map_legend+"'>"+html_ahpm_map_legend+"</div>")
		map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(document.getElementById('ahpm_map_legend'));
		
	  }
	 <?php
		}
	 ?>
	  infoBubble = new InfoBubble(
			{map: map,
			shadowStyle: 0,  // Style de l'ombre de l'infobulle (0, 1 ou 2)
			padding: 0,  // Marge interne de l'infobulle (en px)
			backgroundColor: '#fff',  // Couleur de fond de l'infobulle
			borderRadius: 3, // Angle d'arrondis de la bordure
			arrowSize: 10, // Taille du pointeur sous l'infobulle
			borderWidth: 0,  // Épaisseur de la bordure (en px)
			borderColor: '#fff',
			backgroundColor: '#fff',	// Couleur de la background
			disableAutoPan: false, // Désactiver l'adaptation automatique de l'infobulle
			hideCloseButton: true, // Cacher le bouton 'Fermer'
			arrowPosition: 50,  // Position du pointeur de l'infobulle (en %)
			arrowStyle: 0,  // Type de pointeur (0, 1 ou 2)
			disableAnimation: false,  // Déactiver l'animation à l'ouverture de l'infobulle
			minHeight:150,
			minWidth:300,
			maxWidth:350
		});

		var  i;
		var img_cat_1 = "<?= ($ahpm_options_ploggmap['cat1_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat1_pin_map']:"" ?>";
		var img_cat_2 = "<?= ($ahpm_options_ploggmap['cat2_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat2_pin_map']:"" ?>";
		var img_cat_3 = "<?= ($ahpm_options_ploggmap['cat3_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat3_pin_map']:"" ?>";
		var img_cat_4 = "<?= ($ahpm_options_ploggmap['cat4_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat4_pin_map']:"" ?>";
		var img_cat_5 = "<?= ($ahpm_options_ploggmap['cat5_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat5_pin_map']:"" ?>";
		var img_cat_6 = "<?= ($ahpm_options_ploggmap['cat6_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat6_pin_map']:"" ?>";
		var img_cat_7 = "<?= ($ahpm_options_ploggmap['cat7_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat7_pin_map']:"" ?>";
		
		var bounds = new google.maps.LatLngBounds();
		for (i = 0; i < locations.length; i++) 
		{  
			
			
				comm_lat=locations[i][1];
				comm_lng=locations[i][2];
				
				var img_icon = "";
				switch(locations[i][7])
				{
					case "cat1":
						img_icon = img_cat_1;
					break;
					case "cat2":
						img_icon = img_cat_2;
					break;
					case "cat3":
						img_icon = img_cat_3;
					break;
					case "cat4":
						img_icon = img_cat_4;
					break;
					case "cat5":
						img_icon = img_cat_5;
					break;
					case "cat6":
						img_icon = img_cat_6;
					break;
					case "cat7":
						img_icon = img_cat_7;
					break;
				}
			
			
			if(locations[i][5] == "" )
			{
		/* 	marker = new google.maps.Marker({
					position: new google.maps.LatLng(comm_lat, comm_lng),
					map: map
					
					<?php
					if($ahpm_options_ploggmap['pin_map'])
					{
					?>
					,icon:'<?php bloginfo('template_url'); ?>/images/<?=$ahpm_options_ploggmap['pin_map']?>'
					<?php
					}
					?>
				}); */
				
				marker = new google.maps.Marker({
					position: new google.maps.LatLng(comm_lat, comm_lng),
					map: map,
					icon:img_icon
				});
				
			}
			else
			{
				 marker = new google.maps.Marker({
					position: new google.maps.LatLng(comm_lat, comm_lng),
					map: map
					
					<?php
					if($ahpm_options_ploggmap['main_pin_map'])
					{
					?>
					,icon:'<?php bloginfo('template_url'); ?>/images/<?=$ahpm_options_ploggmap['main_pin_map']?>'
					<?php
					}
					?>
				}); 				
				<?php
				if($atts['centrer_principal'] == 'yes')
				{
					?>
					map.setCenter(new google.maps.LatLng(comm_lat, comm_lng));
					map.setZoom(15); 
					<?php
				}
				?>
				
			} 
			
			
			
			<?php
			if($atts['centrer_principal'] != 'yes')
			{	
			?>
			bounds.extend(marker.position);
			
			<?php
			}
			?>
			
			
			/* (function (i, marker) {
				var current_location=locations[i];
				var poi_id=locations[i][7];
				$("div#ahpm_"+poi_id).hover(function() {
					console.log(current_location);
					marker.setAnimation(google.maps.Animation.BOUNCE);
				}, function() {
				  marker.setAnimation(null);
			});
			
			}(i,marker)); */
			
			markers[locations[i][3]]=marker;
			
			google.maps.event.addListener(marker, 'click', (function(marker, i) {
				return function() {
					/*infowindow.setOptions({
					content: '<div><b><img style="width:175px;height:100px;" src="'+locations[i][4]+'"/><br/> '+locations[i][0]+'<br/><a href="<?php bloginfo('url')?>/commerce/?id_commerce='+locations[i][3]+'" class="button green" >Voir le commerce</a></div></div>'

					});
					infowindow.open(map, marker);*/
					var div_img = "";
			
					if(locations[i][6] != ""){
						infoBubble.minHeight=330;
						div_img = '<div class="photo-wrapper" style="background:url('+locations[i][6]+') center center no-repeat; background-size:cover;"></div>'
					}
					else
					{
						infoBubble.minHeight=150;
						div_img = '';
					}
					infoBubble.setOptions({
					content: 
					'<div class="ahpm_close-button" onClick="infoBubble.close()">X</div>'+
					'<div class="ahpm_my_infowindow">' +
								
								div_img
								+
					      		'<div class="text-wrapper">'+
								'<h3>'+locations[i][0]+'</h3>'+
					      			'<p>'+
					      			locations[i][4]+
					      			
					      			
					      			'</p>'+
						      	
						      		//'<a href="https://www.google.ca/maps/dir/'+locations[i][4]+' '+locations[i][3]+'/" title="Itinéraire vers ce commerce">Itinéraire vers ce lieu »</a>'+
						      		'<a href="https://maps.google.com/?q='+locations[i][4]+' '+locations[i][3]+'" target="_blank" title="<?= __('Itinéraire vers ce lieu','ploggmap_domain') ?>"><?= __('Itinéraire vers ce lieu','ploggmap_domain') ?> »</a>'+
									
								'</div>'+
					      	'</div>'
			      	}); 
			      	/*if (!infoBubble.isOpen()) {*/
						map.panTo(marker.getPosition());
						infoBubble.open(map, marker);
					/*}else{
						infoBubble.close();
					}*/
				}
			})(marker, i));
			

			
		
		}
		
		if(i>0){
			<?php
			if($atts['centrer_principal'] != 'yes')
			{	
			?>
			map.fitBounds(bounds);
			
			<?php
			}
			?>
			var listener = google.maps.event.addListener(map, "idle", function() { 
			  if (map.getZoom() > 16) map.setZoom(14); 
			  google.maps.event.removeListener(listener); 
			});
		}
	  	google.maps.event.addDomListener(window, 'resize', function() {
		    var center = map.getCenter();
			 google.maps.event.trigger(map, "resize");
			 map.setCenter(center); 
		});
	}
	
	function ahpm_initialize_filtred(filtred_loc) {
	
		locations=filtred_loc;
		
	  geocoder = new google.maps.Geocoder();
	  var latlng = new google.maps.LatLng(45.400994, -7.882428);
	  var mapOptions = {
		zoom: 12,
		minZoom: 6,
		center: latlng,
		scrollwheel: false,
		disableDefaultUI: true,
		mapTypeControl: false,
		zoomControl: true,
		zoomControlOptions: {
		    style: google.maps.ZoomControlStyle.SMALL
		},
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		
		<?= ($ahpm_options_ploggmap['style_map'] != "")? "styles:".$ahpm_options_ploggmap['style_map']:"" ?>
	  }
	  
	  map = new google.maps.Map(document.getElementById('ahpm_map_canvas'), mapOptions);
	  
	  <?php
	 if($atts['cat_id'] != 'no')
		{
	 ?>
	 if(jQuery("#ahpm_map_legend").attr('id') == "ahpm_map_legend")
	  {
		
		map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(document.getElementById('ahpm_map_legend'));
		  
	  }
	  else  
	  {
		jQuery("#ahpm_map_canvas").after("<div id='ahpm_map_legend' style='"+style_ahpm_map_legend+"' class='"+class_ahpm_map_legend+"'>"+html_ahpm_map_legend+"</div>")
		map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(document.getElementById('ahpm_map_legend'));
		
	  }
	  <?php
		}
	  ?>
	  infoBubble = new InfoBubble(
			{map: map,
			shadowStyle: 0,  // Style de l'ombre de l'infobulle (0, 1 ou 2)
			padding: 0,  // Marge interne de l'infobulle (en px)
			backgroundColor: '#fff',  // Couleur de fond de l'infobulle
			borderRadius: 3, // Angle d'arrondis de la bordure
			arrowSize: 10, // Taille du pointeur sous l'infobulle
			borderWidth: 0,  // Épaisseur de la bordure (en px)
			borderColor: '#fff',
			backgroundColor: '#fff',	// Couleur de la background
			disableAutoPan: false, // Désactiver l'adaptation automatique de l'infobulle
			hideCloseButton: true, // Cacher le bouton 'Fermer'
			arrowPosition: 50,  // Position du pointeur de l'infobulle (en %)
			arrowStyle: 0,  // Type de pointeur (0, 1 ou 2)
			disableAnimation: false,  // Déactiver l'animation à l'ouverture de l'infobulle
			minHeight:150,
			minWidth:300,
			maxWidth:350
		});

		var  i;
		var img_cat_1 = "<?= ($ahpm_options_ploggmap['cat1_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat1_pin_map']:"" ?>";
		var img_cat_2 = "<?= ($ahpm_options_ploggmap['cat2_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat2_pin_map']:"" ?>";
		var img_cat_3 = "<?= ($ahpm_options_ploggmap['cat3_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat3_pin_map']:"" ?>";
		var img_cat_4 = "<?= ($ahpm_options_ploggmap['cat4_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat4_pin_map']:"" ?>";
		var img_cat_5 = "<?= ($ahpm_options_ploggmap['cat5_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat5_pin_map']:"" ?>";
		var img_cat_6 = "<?= ($ahpm_options_ploggmap['cat6_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat6_pin_map']:"" ?>";
		var img_cat_7 = "<?= ($ahpm_options_ploggmap['cat7_pin_map'])? get_bloginfo('template_url')."/images/".$ahpm_options_ploggmap['cat7_pin_map']:"" ?>";
		
		var bounds = new google.maps.LatLngBounds();
		for (i = 0; i < locations.length; i++) 
		{  
			
			
				comm_lat=locations[i][1];
				comm_lng=locations[i][2];
				
				var img_icon = "";
				switch(locations[i][7])
				{
					case "cat1":
						img_icon = img_cat_1;
					break;
					case "cat2":
						img_icon = img_cat_2;
					break;
					case "cat3":
						img_icon = img_cat_3;
					break;
					case "cat4":
						img_icon = img_cat_4;
					break;
					case "cat5":
						img_icon = img_cat_5;
					break;
					case "cat6":
						img_icon = img_cat_6;
					break;
					case "cat7":
						img_icon = img_cat_7;
					break;
				}
			
			
			if(locations[i][5] == "" )
			{
		/* 	marker = new google.maps.Marker({
					position: new google.maps.LatLng(comm_lat, comm_lng),
					map: map
					
					<?php
					if($ahpm_options_ploggmap['pin_map'])
					{
					?>
					,icon:'<?php bloginfo('template_url'); ?>/images/<?=$ahpm_options_ploggmap['pin_map']?>'
					<?php
					}
					?>
				}); */
				
				marker = new google.maps.Marker({
					position: new google.maps.LatLng(comm_lat, comm_lng),
					map: map,
					icon:img_icon
				});
				
			}
			else
			{
				 marker = new google.maps.Marker({
					position: new google.maps.LatLng(comm_lat, comm_lng),
					map: map
					
					<?php
					if($ahpm_options_ploggmap['main_pin_map'])
					{
					?>
					,icon:'<?php bloginfo('template_url'); ?>/images/<?=$ahpm_options_ploggmap['main_pin_map']?>'
					<?php
					}
					?>
				}); 				
				<?php
				if($atts['centrer_principal'] == 'yes')
				{
					?>
					map.setCenter(new google.maps.LatLng(comm_lat, comm_lng));
					map.setZoom(15); 
					<?php
				}
				?>
				
			} 
			
			
			
			<?php
			if($atts['centrer_principal'] != 'yes')
			{	
			?>
			bounds.extend(marker.position);
			
			<?php
			}
			?>
			
			
			/* (function (i, marker) {
				var current_location=locations[i];
				var poi_id=locations[i][7];
				$("div#ahpm_"+poi_id).hover(function() {
					console.log(current_location);
					marker.setAnimation(google.maps.Animation.BOUNCE);
				}, function() {
				  marker.setAnimation(null);
			});
			
			}(i,marker)); */
			
			markers[locations[i][3]]=marker;
			
			google.maps.event.addListener(marker, 'click', (function(marker, i) {
				return function() {
					/*infowindow.setOptions({
					content: '<div><b><img style="width:175px;height:100px;" src="'+locations[i][4]+'"/><br/> '+locations[i][0]+'<br/><a href="<?php bloginfo('url')?>/commerce/?id_commerce='+locations[i][3]+'" class="button green" >Voir le commerce</a></div></div>'

					});
					infowindow.open(map, marker);*/
					var div_img = "";
			
					if(locations[i][6] != ""){
						infoBubble.minHeight=330;
						div_img = '<div class="photo-wrapper" style="background:url('+locations[i][6]+') center center no-repeat; background-size:cover;"></div>'
					}
					else
					{
						infoBubble.minHeight=150;
						div_img = '';
					}
					infoBubble.setOptions({
					content: 
					'<div class="ahpm_close-button" onClick="infoBubble.close()">X</div>'+
					'<div class="ahpm_my_infowindow">' +
								
								div_img
								+
					      		'<div class="text-wrapper">'+
								'<h3>'+locations[i][0]+'</h3>'+
					      			'<p>'+
					      			locations[i][4]+
					      			
					      			
					      			'</p>'+
						      	
						      		//'<a href="https://www.google.ca/maps/dir/'+locations[i][4]+' '+locations[i][3]+'/" title="Itinéraire vers ce commerce">Itinéraire vers ce lieu »</a>'+
						      		'<a href="https://maps.google.com/?q='+locations[i][4]+' '+locations[i][3]+'" target="_blank" title="<?= __('Itinéraire vers ce lieu','ploggmap_domain') ?>"><?= __('Itinéraire vers ce lieu','ploggmap_domain') ?> »</a>'+
									
								'</div>'+
					      	'</div>'
			      	}); 
			      	/*if (!infoBubble.isOpen()) {*/
						map.panTo(marker.getPosition());
						infoBubble.open(map, marker);
					/*}else{
						infoBubble.close();
					}*/
				}
			})(marker, i));
			

			
		
		}
		
		if(i>0){
			<?php
			if($atts['centrer_principal'] != 'yes')
			{	
			?>
			map.fitBounds(bounds);
			
			<?php
			}
			?>
			var listener = google.maps.event.addListener(map, "idle", function() { 
			  if (map.getZoom() > 16) map.setZoom(14); 
			  google.maps.event.removeListener(listener); 
			});
		}
	  	google.maps.event.addDomListener(window, 'resize', function() {
		    var center = map.getCenter();
			 google.maps.event.trigger(map, "resize");
			 map.setCenter(center); 
		});
	}
   

   


   </script>
   <?php
   
  
   return '';
  
  
}

function ahpm_get_lat_long($address,$ville)
{
	
	$ville = GetCityByID1($ville);
	$ville_name = $ville[0]->ville;
	
	$address = $address.' '.$ville_name;
    $address = str_replace(" ", "+", $address);
   
    $json = file_get_contents("http://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&region=Morocco");


    $json = json_decode($json);

	if($json->{'status'} != 'ZERO_RESULTS')
	{
		$lat = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lat'};
   		$long = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lng'};

	}
	else 
	{
		$json2 = file_get_contents("http://maps.google.com/maps/api/geocode/json?address=$ville_name&sensor=false&region=Morocco");

		$json2 = json_decode($json2);
		$lat = $json2->{'results'}[0]->{'geometry'}->{'location'}->{'lat'};
   		$long = $json2->{'results'}[0]->{'geometry'}->{'location'}->{'lng'};
	}
    
    
	return $lat.",".$long;
}

function ahpm_register_settings() 
{
	
	register_setting('ahpm_settings_group', 'ahpm_settings_ploggmap');
}

function ahpm_ajouter_lien_option() 
{
	add_options_page('Réglages', 'Points d\'intérêts', 'manage_options', 'ahpm-options', 'ahpm_options_page');
}
function ahpm_options_page() 
{
	
	global $ahpm_options_ploggmap;
 
	ob_start(); ?>
	<div class="wrap">
		<h2><?= _e("Réglages de la carte des points d'intérêts",'ploggmap_domain')?></h2>
 
		<form method="post" action="options.php">
 
			<?php settings_fields('ahpm_settings_group'); ?>
			
			<h4><?= _e('Shortcode à utiliser','ploggmap_domain') ?></h4>
			<p><?= _e('Pour utiliser ce plugin le shortcode est','ploggmap_domain')?> : [afficher-map-creche]</p>
			<p><?= _e("Dans le cas où on veut utiliser le plugin sur plusieurs pages on peut définir soit le width et le height (ou juste l'un des 2) comme suit",'ploggmap_domain')?> :</p>
			<p>[afficher-map-creche width="900" height="600"]</p>
			<p><?= _e('Pour afficher les creche sous forme de liste (Sauf ceux marqués comme Point principal) on utilise le shorcode','ploggmap_domain')?> : [afficher-liste-creche]</p>
			<p><?= _e('Pour centrer la map sur le point principal','ploggmap_domain') ?> : [afficher-map-creche centrer_principal=yes]</p>
			<p><?= _e('Pour afficher seulement le(s) point(s) principal','ploggmap_domain')?> : [afficher-map-creche principales_seulement=yes]</p>
			<hr/>
			<h4><?php _e('Dimensions de la map','ploggmap_domain')?></h4>
			<p>
				<label class="description" for="ahpm_settings_ploggmap[width_map]"><?php _e('Width de la map (en px): ','ploggmap_domain'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[width_map]" name="ahpm_settings_ploggmap[width_map]" type="text" value="<?php echo $ahpm_options_ploggmap['width_map']; ?>"/>
			</p>
			<p>
				<label class="description" for="ahpm_settings_ploggmap[height_map]"><?php _e('Height de la map (en px): ','ploggmap_domain'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[height_map]" name="ahpm_settings_ploggmap[height_map]" type="text" value="<?php echo $ahpm_options_ploggmap['height_map']; ?>"/>
			</p>
			<hr/>
			<p>
				<h4><?php _e('Style de la map : ','ploggmap_domain'); ?></h4>
				<textarea style="width:500px;height:230px;" id="ahpm_settings_ploggmap[style_map]" name="ahpm_settings_ploggmap[style_map]" type="text"><?php echo $ahpm_options_ploggmap['style_map']; ?></textarea>
			</p>
			<p style="color:red;font-weight: bold;">
			<?= _e('NB : Le style à mettre et du genre','ploggmap_domain') ?> : [  { ..... },{ ..... },{ ..... } ]
			</p>
			<hr/>
		
			<h4><?php _e('Images des pins','ploggmap_domain')?></h4>
			<p>
				<label class="description" for="ahpm_settings_ploggmap[pin_map]"><?php _e('Nom Image pour le pin de la map : '); ?></label><br/>
				<input id="ahpm_settings_ploggmap[pin_map]" name="ahpm_settings_ploggmap[pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['pin_map']; ?>"/>
			</p>
			<p>
				<label class="description" for="ahpm_settings_ploggmap[main_pin_map]"><?php _e('Nom Image pour le pin central de la map : '); ?></label><br/>
				<input id="ahpm_settings_ploggmap[main_pin_map]" name="ahpm_settings_ploggmap[main_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['main_pin_map']; ?>"/>
			</p>
			
			<p style="color:red;font-weight: bold;">
			(<?= _e('NB : Les images doit se situer dans le dossier','ploggmap_domain') ?> <?= get_bloginfo("template_url")."/images"?>)
			</p>
			<hr/>
			<h4>Region Crèche</h4>
			<p>
				<label class="description" for="ahpm_settings_ploggmap[cat1_pin_map]"><?php _e('Nom Image pour le pin de la Région : Tanger-Tétouan-Al Hoceïma'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[cat1_pin_map]" name="ahpm_settings_ploggmap[cat1_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['cat1_pin_map']; ?>"/>
			</p>
			<p>	
				<label class="description" for="ahpm_settings_ploggmap[cat2_pin_map]"><?php _e('Nom Image pour le pin de la Région : Oriental'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[cat2_pin_map]" name="ahpm_settings_ploggmap[cat2_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['cat2_pin_map']; ?>"/>
			</p>
			<p>	
				<label class="description" for="ahpm_settings_ploggmap[cat3_pin_map]"><?php _e('Nom Image pour le pin de la Région : Fès-Meknès'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[cat3_pin_map]" name="ahpm_settings_ploggmap[cat3_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['cat3_pin_map']; ?>"/>
			</p>
			<p>	
				<label class="description" for="ahpm_settings_ploggmap[cat4_pin_map]"><?php _e('Nom Image pour le pin de la Région : Rabat-Salé-Kénitra'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[cat4_pin_map]" name="ahpm_settings_ploggmap[cat4_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['cat4_pin_map']; ?>"/>
			</p>
			<p>	
				<label class="description" for="ahpm_settings_ploggmap[cat5_pin_map]"><?php _e('Nom Image pour le pin de la Région : Béni Mellal-Khénifrae'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[cat5_pin_map]" name="ahpm_settings_ploggmap[cat5_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['cat5_pin_map']; ?>"/>
			</p>
			<p>	
				<label class="description" for="ahpm_settings_ploggmap[cat6_pin_map]"><?php _e('Nom Image pour le pin de la Région : Casablanca-Settat'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[cat6_pin_map]" name="ahpm_settings_ploggmap[cat6_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['cat6_pin_map']; ?>"/>
			</p>
			<p>	
				<label class="description" for="ahpm_settings_ploggmap[cat7_pin_map]"><?php _e('Nom Image pour le pin de la Région : Marrakech-Safi'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[cat7_pin_map]" name="ahpm_settings_ploggmap[cat7_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['cat7_pin_map']; ?>"/>
			</p>
<p>	
				<label class="description" for="ahpm_settings_ploggmap[cat8_pin_map]"><?php _e('Nom Image pour le pin de la Région : Drâa-Tafilalet'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[cat8_pin_map]" name="ahpm_settings_ploggmap[cat8_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['cat8_pin_map']; ?>"/>
			</p>
<p>	
				<label class="description" for="ahpm_settings_ploggmap[cat9_pin_map]"><?php _e('Nom Image pour le pin de la Région : Souss-Massa'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[cat9_pin_map]" name="ahpm_settings_ploggmap[cat9_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['cat9_pin_map']; ?>"/>
			</p>
<p>	
				<label class="description" for="ahpm_settings_ploggmap[cat10_pin_map]"><?php _e('Nom Image pour le pin de la Région :  Guelmim-Oued Noun'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[cat10_pin_map]" name="ahpm_settings_ploggmap[cat10_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['cat10_pin_map']; ?>"/>
			</p><p>	
				<label class="description" for="ahpm_settings_ploggmap[cat11_pin_map]"><?php _e('Nom Image pour le pin de la Région : Laâyoune-Sakia El Hamra'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[cat11_pin_map]" name="ahpm_settings_ploggmap[cat11_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['cat11_pin_map']; ?>"/>
			</p>
<p>	
				<label class="description" for="ahpm_settings_ploggmap[cat12_pin_map]"><?php _e('Nom Image pour le pin de la Région : Dakhla-Oued Ed Dahab'); ?></label><br/>
				<input id="ahpm_settings_ploggmap[cat12_pin_map]" name="ahpm_settings_ploggmap[cat12_pin_map]" type="text" value="<?php echo $ahpm_options_ploggmap['cat12_pin_map']; ?>"/>
			</p>			
				<p style="color:red;font-weight: bold;">
			(<?= _e('NB : Les images doit se situer dans le dossier','ploggmap_domain') ?> <?= get_bloginfo("template_url")."/images"?>)
			</p>
			<hr/>
			<p class="submit">
				<input type="submit" class="button-primary" value="<?php _e('Enregistrer les réglages','ploggmap_domain'); ?>" />
			</p>
 
		</form>
 
	</div>
	<?php
	echo ob_get_clean();
}


function GetCityByID1($id) {
	global $wpdb;
	$result =  $wpdb->get_results("select * from `bc_ville` where id = $id" );   
	return $result;
}
 

function ahpm_charger_js_poi()
{
	add_action('wp_enqueue_scripts', 'ahpm_load_ressources');
	
}


function ahpm_process_ajax()
{
	if(isset($_POST['ahpm_addr']))
	{
		$ville = $_POST['ahpm_ville'];
		$map    =   ahpm_get_lat_long($_POST['ahpm_addr'],$ville );
		$arr_map=explode(",",$map);
		
		if($arr_map[0] != "" and $arr_map[1] != "") echo $arr_map[0].",".$arr_map[1];
		else echo "err,err";
	}
	else echo "err1,err1";
	die();
}



?>
