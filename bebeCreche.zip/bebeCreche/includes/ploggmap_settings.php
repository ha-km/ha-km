<?php

add_action('admin_init', 'ahpm_register_settings');


add_action('admin_menu', 'ahpm_ajouter_lien_option');

?>