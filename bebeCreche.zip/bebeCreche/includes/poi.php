<?php

// Ajouter le custom post POI
add_action( 'init', 'ahpm_ajouter_poi' );

// Ajouter le metabox pour les POI
add_action( 'admin_init', 'ahpm_poi_metabox' );

// Sauvegarder les informations des POI
add_action( 'save_post', 'ahpm_enregistrer_infos_poi', 10, 2 );



// Ajouter le traitement ajax pour r�cup�rer les coordonn�es des POI
add_action('wp_ajax_ahpm_get_latlng_poi','ahpm_process_ajax');


?>