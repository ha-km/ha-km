<?php

	//if uninstall not called from WordPress exit
	if ( !defined( 'WP_UNINSTALL_PLUGIN' ) ) 
		exit();

	$option_name = 'ahpm_settings_ploggmap';

	delete_option( $option_name );

	


?>